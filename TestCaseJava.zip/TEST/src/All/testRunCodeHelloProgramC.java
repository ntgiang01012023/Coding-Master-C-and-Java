package All;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class testRunCodeHelloProgramC {
	
	private WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:5173/");
    }

    @Test
    public void testRunCodeHelloC() throws InterruptedException {
        WebElement div_element = driver.findElement(By.className("box-left-c"));
        WebElement textarea_element = div_element.findElement(By.tagName("textarea"));       
        String cCode = "#include <stdio.h>\n" +
                "int main() {\n" +
                "    printf(\"Hello Program C!\");\n" +
                "    return 0;\n" +
                "}";
        textarea_element.sendKeys(cCode);
        WebElement submit = driver.findElement(By.id("btn-run-c"));
        submit.click();  
        Thread.sleep(10000);
        WebElement preElement = driver.findElement(By.className("box-right-c")).findElement(By.tagName("pre"));
        String result = preElement.getText();
        System.out.println("Result: " + result);
    }
    
    @Test
    public void testRunCodeEmptyPrintf() throws InterruptedException {
        WebElement div_element = driver.findElement(By.className("box-left-c"));
        WebElement textarea_element = div_element.findElement(By.tagName("textarea"));       
        String cCode = "#include <stdio.h>\n" +
                "int main() {\n" +
                "    printf(\"\");\n" +
                "    return 0;\n" +
                "}";
        textarea_element.sendKeys(cCode);
        WebElement submit = driver.findElement(By.id("btn-run-c"));
        submit.click();  
        Thread.sleep(10000);
        WebElement preElement = driver.findElement(By.className("box-right-c")).findElement(By.tagName("pre"));
        String result = preElement.getText();
        System.out.println("Result: " + result);
    }
    
    @Test
    public void testRunCodeEmpty() throws InterruptedException {
        WebElement div_element = driver.findElement(By.className("box-left-c"));
        WebElement textarea_element = div_element.findElement(By.tagName("textarea"));       
        String cCode = "";
        textarea_element.sendKeys(cCode);
        WebElement submit = driver.findElement(By.id("btn-run-c"));
        submit.click();  
        Thread.sleep(10000);
        WebElement preElement = driver.findElement(By.className("box-right-c")).findElement(By.tagName("pre"));
        String result = preElement.getText();
        System.out.println("Result: " + result);
    }
    

    @AfterMethod
    public void tearDown() throws InterruptedException {
    	Thread.sleep(3000);
    	driver.close();
    }
}
